<?php
	header("HTTP/1.1 200 OK");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>200 OK : Esborrada</title>
	</head>
	<body>
		<h2>200 OK : S'ha esborrat amb èxit, refresca la pàgina per veure els canvis</h2>		
	</body>
</html>

