<?php
	header("HTTP/1.1 404 Not Found");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Error 404 : Noo existeix</title>
	</head>
	<body>
		<h2>Error 404: Aquest ja no existeix</h2>		
	</body>
</html>
